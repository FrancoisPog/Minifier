François POGUET
Enzo COSTANTINI

Bilan sur la version finale : 
    - Le script final est conforme à nos prévisions et correspond, selon nous, aux besoins indiqués.
    - Pour la gestion des options saisies, nous avons choisi d'implementer des variables "flags", 
    cela permet de simplifier la saisie, il n'y a pas d'ordre et les options "simple" peuvent être saisies en groupe (ex : -vf).
    L'implémentation permet aussi d'ajouter des options au script très facilement.
    - Sachant que certains espaces avant et après des parenthèses sont indispensables pour garder un css valide, nous avons choisi
    d'implémenter l'option -p pour laisser le choix à l'utilisateur de supprimer ou non les espaces précédants et suivants des parenthèses.
    (Remarque : le gains d'utilisation de cette option est ultra minime (< 0.1%))
    - Nous avons testé les saisies d'options invalides ainsi que l'execution du script avec des permissions différentes.

Bilan technique :
    - La commande 'sed' a été largement utilisée, notamment lors de la minification des fichiers.
    - Pour calculer le taux de réduction, nous avons utilisé la commande bc.
    - Pour l'architecture du code, nous avons essayé de créer une fonction pour chaque tâche.

Améliorations possibles : 
    - Il pourrait être judicieux d'integrer une option pour minifier des fichiers PHP/JS.

Travail en binôme : 
    - Nous avons utilisé un dossier OneDrive pour partager le projet de manière synchronisée.

